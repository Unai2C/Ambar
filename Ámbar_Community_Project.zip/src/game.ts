import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../7d669c08-c354-45e4-b3a3-c915c8fd6b6e/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const sceneAMBARPROJECT = new Entity('sceneAMBARPROJECT')
engine.addEntity(sceneAMBARPROJECT)
sceneAMBARPROJECT.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(71.5, 0, 76.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
sceneAMBARPROJECT.addComponentOrReplace(transform2)
const gltfShape = new GLTFShape("807742a4-50f2-42e1-9aef-bd119cba3bda/SCENE_AMBAR_PROJECT.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
sceneAMBARPROJECT.addComponentOrReplace(gltfShape)

const bermudaGrass = new Entity('bermudaGrass')
engine.addEntity(bermudaGrass)
bermudaGrass.setParent(_scene)
const gltfShape2 = new GLTFShape("c9b17021-765c-4d9a-9966-ce93a9c323d1/FloorBaseGrass_01/FloorBaseGrass_01.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
bermudaGrass.addComponentOrReplace(gltfShape2)
const transform3 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass.addComponentOrReplace(transform3)

const bermudaGrass2 = new Entity('bermudaGrass2')
engine.addEntity(bermudaGrass2)
bermudaGrass2.setParent(_scene)
bermudaGrass2.addComponentOrReplace(gltfShape2)
const transform4 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass2.addComponentOrReplace(transform4)

const bermudaGrass3 = new Entity('bermudaGrass3')
engine.addEntity(bermudaGrass3)
bermudaGrass3.setParent(_scene)
bermudaGrass3.addComponentOrReplace(gltfShape2)
const transform5 = new Transform({
  position: new Vector3(40, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass3.addComponentOrReplace(transform5)

const bermudaGrass4 = new Entity('bermudaGrass4')
engine.addEntity(bermudaGrass4)
bermudaGrass4.setParent(_scene)
bermudaGrass4.addComponentOrReplace(gltfShape2)
const transform6 = new Transform({
  position: new Vector3(56, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass4.addComponentOrReplace(transform6)

const bermudaGrass5 = new Entity('bermudaGrass5')
engine.addEntity(bermudaGrass5)
bermudaGrass5.setParent(_scene)
bermudaGrass5.addComponentOrReplace(gltfShape2)
const transform7 = new Transform({
  position: new Vector3(72, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass5.addComponentOrReplace(transform7)

const bermudaGrass6 = new Entity('bermudaGrass6')
engine.addEntity(bermudaGrass6)
bermudaGrass6.setParent(_scene)
bermudaGrass6.addComponentOrReplace(gltfShape2)
const transform8 = new Transform({
  position: new Vector3(88, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass6.addComponentOrReplace(transform8)

const bermudaGrass7 = new Entity('bermudaGrass7')
engine.addEntity(bermudaGrass7)
bermudaGrass7.setParent(_scene)
bermudaGrass7.addComponentOrReplace(gltfShape2)
const transform9 = new Transform({
  position: new Vector3(104, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass7.addComponentOrReplace(transform9)

const bermudaGrass8 = new Entity('bermudaGrass8')
engine.addEntity(bermudaGrass8)
bermudaGrass8.setParent(_scene)
bermudaGrass8.addComponentOrReplace(gltfShape2)
const transform10 = new Transform({
  position: new Vector3(120, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass8.addComponentOrReplace(transform10)

const bermudaGrass9 = new Entity('bermudaGrass9')
engine.addEntity(bermudaGrass9)
bermudaGrass9.setParent(_scene)
bermudaGrass9.addComponentOrReplace(gltfShape2)
const transform11 = new Transform({
  position: new Vector3(136, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass9.addComponentOrReplace(transform11)

const bermudaGrass10 = new Entity('bermudaGrass10')
engine.addEntity(bermudaGrass10)
bermudaGrass10.setParent(_scene)
bermudaGrass10.addComponentOrReplace(gltfShape2)
const transform12 = new Transform({
  position: new Vector3(152, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass10.addComponentOrReplace(transform12)

const bermudaGrass11 = new Entity('bermudaGrass11')
engine.addEntity(bermudaGrass11)
bermudaGrass11.setParent(_scene)
bermudaGrass11.addComponentOrReplace(gltfShape2)
const transform13 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass11.addComponentOrReplace(transform13)

const bermudaGrass12 = new Entity('bermudaGrass12')
engine.addEntity(bermudaGrass12)
bermudaGrass12.setParent(_scene)
bermudaGrass12.addComponentOrReplace(gltfShape2)
const transform14 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass12.addComponentOrReplace(transform14)

const bermudaGrass13 = new Entity('bermudaGrass13')
engine.addEntity(bermudaGrass13)
bermudaGrass13.setParent(_scene)
bermudaGrass13.addComponentOrReplace(gltfShape2)
const transform15 = new Transform({
  position: new Vector3(40, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass13.addComponentOrReplace(transform15)

const bermudaGrass14 = new Entity('bermudaGrass14')
engine.addEntity(bermudaGrass14)
bermudaGrass14.setParent(_scene)
bermudaGrass14.addComponentOrReplace(gltfShape2)
const transform16 = new Transform({
  position: new Vector3(56, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass14.addComponentOrReplace(transform16)

const bermudaGrass15 = new Entity('bermudaGrass15')
engine.addEntity(bermudaGrass15)
bermudaGrass15.setParent(_scene)
bermudaGrass15.addComponentOrReplace(gltfShape2)
const transform17 = new Transform({
  position: new Vector3(72, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass15.addComponentOrReplace(transform17)

const bermudaGrass16 = new Entity('bermudaGrass16')
engine.addEntity(bermudaGrass16)
bermudaGrass16.setParent(_scene)
bermudaGrass16.addComponentOrReplace(gltfShape2)
const transform18 = new Transform({
  position: new Vector3(88, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass16.addComponentOrReplace(transform18)

const bermudaGrass17 = new Entity('bermudaGrass17')
engine.addEntity(bermudaGrass17)
bermudaGrass17.setParent(_scene)
bermudaGrass17.addComponentOrReplace(gltfShape2)
const transform19 = new Transform({
  position: new Vector3(104, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass17.addComponentOrReplace(transform19)

const bermudaGrass18 = new Entity('bermudaGrass18')
engine.addEntity(bermudaGrass18)
bermudaGrass18.setParent(_scene)
bermudaGrass18.addComponentOrReplace(gltfShape2)
const transform20 = new Transform({
  position: new Vector3(120, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass18.addComponentOrReplace(transform20)

const bermudaGrass19 = new Entity('bermudaGrass19')
engine.addEntity(bermudaGrass19)
bermudaGrass19.setParent(_scene)
bermudaGrass19.addComponentOrReplace(gltfShape2)
const transform21 = new Transform({
  position: new Vector3(136, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass19.addComponentOrReplace(transform21)

const bermudaGrass20 = new Entity('bermudaGrass20')
engine.addEntity(bermudaGrass20)
bermudaGrass20.setParent(_scene)
bermudaGrass20.addComponentOrReplace(gltfShape2)
const transform22 = new Transform({
  position: new Vector3(152, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass20.addComponentOrReplace(transform22)

const bermudaGrass21 = new Entity('bermudaGrass21')
engine.addEntity(bermudaGrass21)
bermudaGrass21.setParent(_scene)
bermudaGrass21.addComponentOrReplace(gltfShape2)
const transform23 = new Transform({
  position: new Vector3(8, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass21.addComponentOrReplace(transform23)

const bermudaGrass22 = new Entity('bermudaGrass22')
engine.addEntity(bermudaGrass22)
bermudaGrass22.setParent(_scene)
bermudaGrass22.addComponentOrReplace(gltfShape2)
const transform24 = new Transform({
  position: new Vector3(24, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass22.addComponentOrReplace(transform24)

const bermudaGrass23 = new Entity('bermudaGrass23')
engine.addEntity(bermudaGrass23)
bermudaGrass23.setParent(_scene)
bermudaGrass23.addComponentOrReplace(gltfShape2)
const transform25 = new Transform({
  position: new Vector3(40, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass23.addComponentOrReplace(transform25)

const bermudaGrass24 = new Entity('bermudaGrass24')
engine.addEntity(bermudaGrass24)
bermudaGrass24.setParent(_scene)
bermudaGrass24.addComponentOrReplace(gltfShape2)
const transform26 = new Transform({
  position: new Vector3(56, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass24.addComponentOrReplace(transform26)

const bermudaGrass25 = new Entity('bermudaGrass25')
engine.addEntity(bermudaGrass25)
bermudaGrass25.setParent(_scene)
bermudaGrass25.addComponentOrReplace(gltfShape2)
const transform27 = new Transform({
  position: new Vector3(72, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass25.addComponentOrReplace(transform27)

const bermudaGrass26 = new Entity('bermudaGrass26')
engine.addEntity(bermudaGrass26)
bermudaGrass26.setParent(_scene)
bermudaGrass26.addComponentOrReplace(gltfShape2)
const transform28 = new Transform({
  position: new Vector3(88, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass26.addComponentOrReplace(transform28)

const bermudaGrass27 = new Entity('bermudaGrass27')
engine.addEntity(bermudaGrass27)
bermudaGrass27.setParent(_scene)
bermudaGrass27.addComponentOrReplace(gltfShape2)
const transform29 = new Transform({
  position: new Vector3(104, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass27.addComponentOrReplace(transform29)

const bermudaGrass28 = new Entity('bermudaGrass28')
engine.addEntity(bermudaGrass28)
bermudaGrass28.setParent(_scene)
bermudaGrass28.addComponentOrReplace(gltfShape2)
const transform30 = new Transform({
  position: new Vector3(120, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass28.addComponentOrReplace(transform30)

const bermudaGrass29 = new Entity('bermudaGrass29')
engine.addEntity(bermudaGrass29)
bermudaGrass29.setParent(_scene)
bermudaGrass29.addComponentOrReplace(gltfShape2)
const transform31 = new Transform({
  position: new Vector3(136, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass29.addComponentOrReplace(transform31)

const bermudaGrass30 = new Entity('bermudaGrass30')
engine.addEntity(bermudaGrass30)
bermudaGrass30.setParent(_scene)
bermudaGrass30.addComponentOrReplace(gltfShape2)
const transform32 = new Transform({
  position: new Vector3(152, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass30.addComponentOrReplace(transform32)

const bermudaGrass31 = new Entity('bermudaGrass31')
engine.addEntity(bermudaGrass31)
bermudaGrass31.setParent(_scene)
bermudaGrass31.addComponentOrReplace(gltfShape2)
const transform33 = new Transform({
  position: new Vector3(8, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass31.addComponentOrReplace(transform33)

const bermudaGrass32 = new Entity('bermudaGrass32')
engine.addEntity(bermudaGrass32)
bermudaGrass32.setParent(_scene)
bermudaGrass32.addComponentOrReplace(gltfShape2)
const transform34 = new Transform({
  position: new Vector3(24, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass32.addComponentOrReplace(transform34)

const bermudaGrass33 = new Entity('bermudaGrass33')
engine.addEntity(bermudaGrass33)
bermudaGrass33.setParent(_scene)
bermudaGrass33.addComponentOrReplace(gltfShape2)
const transform35 = new Transform({
  position: new Vector3(40, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass33.addComponentOrReplace(transform35)

const bermudaGrass34 = new Entity('bermudaGrass34')
engine.addEntity(bermudaGrass34)
bermudaGrass34.setParent(_scene)
bermudaGrass34.addComponentOrReplace(gltfShape2)
const transform36 = new Transform({
  position: new Vector3(56, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass34.addComponentOrReplace(transform36)

const bermudaGrass35 = new Entity('bermudaGrass35')
engine.addEntity(bermudaGrass35)
bermudaGrass35.setParent(_scene)
bermudaGrass35.addComponentOrReplace(gltfShape2)
const transform37 = new Transform({
  position: new Vector3(72, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass35.addComponentOrReplace(transform37)

const bermudaGrass36 = new Entity('bermudaGrass36')
engine.addEntity(bermudaGrass36)
bermudaGrass36.setParent(_scene)
bermudaGrass36.addComponentOrReplace(gltfShape2)
const transform38 = new Transform({
  position: new Vector3(88, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass36.addComponentOrReplace(transform38)

const bermudaGrass37 = new Entity('bermudaGrass37')
engine.addEntity(bermudaGrass37)
bermudaGrass37.setParent(_scene)
bermudaGrass37.addComponentOrReplace(gltfShape2)
const transform39 = new Transform({
  position: new Vector3(104, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass37.addComponentOrReplace(transform39)

const bermudaGrass38 = new Entity('bermudaGrass38')
engine.addEntity(bermudaGrass38)
bermudaGrass38.setParent(_scene)
bermudaGrass38.addComponentOrReplace(gltfShape2)
const transform40 = new Transform({
  position: new Vector3(120, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass38.addComponentOrReplace(transform40)

const bermudaGrass39 = new Entity('bermudaGrass39')
engine.addEntity(bermudaGrass39)
bermudaGrass39.setParent(_scene)
bermudaGrass39.addComponentOrReplace(gltfShape2)
const transform41 = new Transform({
  position: new Vector3(136, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass39.addComponentOrReplace(transform41)

const bermudaGrass40 = new Entity('bermudaGrass40')
engine.addEntity(bermudaGrass40)
bermudaGrass40.setParent(_scene)
bermudaGrass40.addComponentOrReplace(gltfShape2)
const transform42 = new Transform({
  position: new Vector3(152, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass40.addComponentOrReplace(transform42)

const bermudaGrass41 = new Entity('bermudaGrass41')
engine.addEntity(bermudaGrass41)
bermudaGrass41.setParent(_scene)
bermudaGrass41.addComponentOrReplace(gltfShape2)
const transform43 = new Transform({
  position: new Vector3(8, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass41.addComponentOrReplace(transform43)

const bermudaGrass42 = new Entity('bermudaGrass42')
engine.addEntity(bermudaGrass42)
bermudaGrass42.setParent(_scene)
bermudaGrass42.addComponentOrReplace(gltfShape2)
const transform44 = new Transform({
  position: new Vector3(24, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass42.addComponentOrReplace(transform44)

const bermudaGrass43 = new Entity('bermudaGrass43')
engine.addEntity(bermudaGrass43)
bermudaGrass43.setParent(_scene)
bermudaGrass43.addComponentOrReplace(gltfShape2)
const transform45 = new Transform({
  position: new Vector3(40, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass43.addComponentOrReplace(transform45)

const bermudaGrass44 = new Entity('bermudaGrass44')
engine.addEntity(bermudaGrass44)
bermudaGrass44.setParent(_scene)
bermudaGrass44.addComponentOrReplace(gltfShape2)
const transform46 = new Transform({
  position: new Vector3(56, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass44.addComponentOrReplace(transform46)

const bermudaGrass45 = new Entity('bermudaGrass45')
engine.addEntity(bermudaGrass45)
bermudaGrass45.setParent(_scene)
bermudaGrass45.addComponentOrReplace(gltfShape2)
const transform47 = new Transform({
  position: new Vector3(72, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass45.addComponentOrReplace(transform47)

const bermudaGrass46 = new Entity('bermudaGrass46')
engine.addEntity(bermudaGrass46)
bermudaGrass46.setParent(_scene)
bermudaGrass46.addComponentOrReplace(gltfShape2)
const transform48 = new Transform({
  position: new Vector3(88, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass46.addComponentOrReplace(transform48)

const bermudaGrass47 = new Entity('bermudaGrass47')
engine.addEntity(bermudaGrass47)
bermudaGrass47.setParent(_scene)
bermudaGrass47.addComponentOrReplace(gltfShape2)
const transform49 = new Transform({
  position: new Vector3(104, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass47.addComponentOrReplace(transform49)

const bermudaGrass48 = new Entity('bermudaGrass48')
engine.addEntity(bermudaGrass48)
bermudaGrass48.setParent(_scene)
bermudaGrass48.addComponentOrReplace(gltfShape2)
const transform50 = new Transform({
  position: new Vector3(120, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass48.addComponentOrReplace(transform50)

const bermudaGrass49 = new Entity('bermudaGrass49')
engine.addEntity(bermudaGrass49)
bermudaGrass49.setParent(_scene)
bermudaGrass49.addComponentOrReplace(gltfShape2)
const transform51 = new Transform({
  position: new Vector3(136, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass49.addComponentOrReplace(transform51)

const bermudaGrass50 = new Entity('bermudaGrass50')
engine.addEntity(bermudaGrass50)
bermudaGrass50.setParent(_scene)
bermudaGrass50.addComponentOrReplace(gltfShape2)
const transform52 = new Transform({
  position: new Vector3(152, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass50.addComponentOrReplace(transform52)

const bermudaGrass51 = new Entity('bermudaGrass51')
engine.addEntity(bermudaGrass51)
bermudaGrass51.setParent(_scene)
bermudaGrass51.addComponentOrReplace(gltfShape2)
const transform53 = new Transform({
  position: new Vector3(8, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass51.addComponentOrReplace(transform53)

const bermudaGrass52 = new Entity('bermudaGrass52')
engine.addEntity(bermudaGrass52)
bermudaGrass52.setParent(_scene)
bermudaGrass52.addComponentOrReplace(gltfShape2)
const transform54 = new Transform({
  position: new Vector3(24, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass52.addComponentOrReplace(transform54)

const bermudaGrass53 = new Entity('bermudaGrass53')
engine.addEntity(bermudaGrass53)
bermudaGrass53.setParent(_scene)
bermudaGrass53.addComponentOrReplace(gltfShape2)
const transform55 = new Transform({
  position: new Vector3(40, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass53.addComponentOrReplace(transform55)

const bermudaGrass54 = new Entity('bermudaGrass54')
engine.addEntity(bermudaGrass54)
bermudaGrass54.setParent(_scene)
bermudaGrass54.addComponentOrReplace(gltfShape2)
const transform56 = new Transform({
  position: new Vector3(56, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass54.addComponentOrReplace(transform56)

const bermudaGrass55 = new Entity('bermudaGrass55')
engine.addEntity(bermudaGrass55)
bermudaGrass55.setParent(_scene)
bermudaGrass55.addComponentOrReplace(gltfShape2)
const transform57 = new Transform({
  position: new Vector3(72, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass55.addComponentOrReplace(transform57)

const bermudaGrass56 = new Entity('bermudaGrass56')
engine.addEntity(bermudaGrass56)
bermudaGrass56.setParent(_scene)
bermudaGrass56.addComponentOrReplace(gltfShape2)
const transform58 = new Transform({
  position: new Vector3(88, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass56.addComponentOrReplace(transform58)

const bermudaGrass57 = new Entity('bermudaGrass57')
engine.addEntity(bermudaGrass57)
bermudaGrass57.setParent(_scene)
bermudaGrass57.addComponentOrReplace(gltfShape2)
const transform59 = new Transform({
  position: new Vector3(104, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass57.addComponentOrReplace(transform59)

const bermudaGrass58 = new Entity('bermudaGrass58')
engine.addEntity(bermudaGrass58)
bermudaGrass58.setParent(_scene)
bermudaGrass58.addComponentOrReplace(gltfShape2)
const transform60 = new Transform({
  position: new Vector3(120, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass58.addComponentOrReplace(transform60)

const bermudaGrass59 = new Entity('bermudaGrass59')
engine.addEntity(bermudaGrass59)
bermudaGrass59.setParent(_scene)
bermudaGrass59.addComponentOrReplace(gltfShape2)
const transform61 = new Transform({
  position: new Vector3(136, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass59.addComponentOrReplace(transform61)

const bermudaGrass60 = new Entity('bermudaGrass60')
engine.addEntity(bermudaGrass60)
bermudaGrass60.setParent(_scene)
bermudaGrass60.addComponentOrReplace(gltfShape2)
const transform62 = new Transform({
  position: new Vector3(152, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass60.addComponentOrReplace(transform62)

const bermudaGrass61 = new Entity('bermudaGrass61')
engine.addEntity(bermudaGrass61)
bermudaGrass61.setParent(_scene)
bermudaGrass61.addComponentOrReplace(gltfShape2)
const transform63 = new Transform({
  position: new Vector3(8, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass61.addComponentOrReplace(transform63)

const bermudaGrass62 = new Entity('bermudaGrass62')
engine.addEntity(bermudaGrass62)
bermudaGrass62.setParent(_scene)
bermudaGrass62.addComponentOrReplace(gltfShape2)
const transform64 = new Transform({
  position: new Vector3(24, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass62.addComponentOrReplace(transform64)

const bermudaGrass63 = new Entity('bermudaGrass63')
engine.addEntity(bermudaGrass63)
bermudaGrass63.setParent(_scene)
bermudaGrass63.addComponentOrReplace(gltfShape2)
const transform65 = new Transform({
  position: new Vector3(40, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass63.addComponentOrReplace(transform65)

const bermudaGrass64 = new Entity('bermudaGrass64')
engine.addEntity(bermudaGrass64)
bermudaGrass64.setParent(_scene)
bermudaGrass64.addComponentOrReplace(gltfShape2)
const transform66 = new Transform({
  position: new Vector3(56, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass64.addComponentOrReplace(transform66)

const bermudaGrass65 = new Entity('bermudaGrass65')
engine.addEntity(bermudaGrass65)
bermudaGrass65.setParent(_scene)
bermudaGrass65.addComponentOrReplace(gltfShape2)
const transform67 = new Transform({
  position: new Vector3(72, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass65.addComponentOrReplace(transform67)

const bermudaGrass66 = new Entity('bermudaGrass66')
engine.addEntity(bermudaGrass66)
bermudaGrass66.setParent(_scene)
bermudaGrass66.addComponentOrReplace(gltfShape2)
const transform68 = new Transform({
  position: new Vector3(88, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass66.addComponentOrReplace(transform68)

const bermudaGrass67 = new Entity('bermudaGrass67')
engine.addEntity(bermudaGrass67)
bermudaGrass67.setParent(_scene)
bermudaGrass67.addComponentOrReplace(gltfShape2)
const transform69 = new Transform({
  position: new Vector3(104, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass67.addComponentOrReplace(transform69)

const bermudaGrass68 = new Entity('bermudaGrass68')
engine.addEntity(bermudaGrass68)
bermudaGrass68.setParent(_scene)
bermudaGrass68.addComponentOrReplace(gltfShape2)
const transform70 = new Transform({
  position: new Vector3(120, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass68.addComponentOrReplace(transform70)

const bermudaGrass69 = new Entity('bermudaGrass69')
engine.addEntity(bermudaGrass69)
bermudaGrass69.setParent(_scene)
bermudaGrass69.addComponentOrReplace(gltfShape2)
const transform71 = new Transform({
  position: new Vector3(136, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass69.addComponentOrReplace(transform71)

const bermudaGrass70 = new Entity('bermudaGrass70')
engine.addEntity(bermudaGrass70)
bermudaGrass70.setParent(_scene)
bermudaGrass70.addComponentOrReplace(gltfShape2)
const transform72 = new Transform({
  position: new Vector3(152, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass70.addComponentOrReplace(transform72)

const bermudaGrass71 = new Entity('bermudaGrass71')
engine.addEntity(bermudaGrass71)
bermudaGrass71.setParent(_scene)
bermudaGrass71.addComponentOrReplace(gltfShape2)
const transform73 = new Transform({
  position: new Vector3(8, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass71.addComponentOrReplace(transform73)

const bermudaGrass72 = new Entity('bermudaGrass72')
engine.addEntity(bermudaGrass72)
bermudaGrass72.setParent(_scene)
bermudaGrass72.addComponentOrReplace(gltfShape2)
const transform74 = new Transform({
  position: new Vector3(24, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass72.addComponentOrReplace(transform74)

const bermudaGrass73 = new Entity('bermudaGrass73')
engine.addEntity(bermudaGrass73)
bermudaGrass73.setParent(_scene)
bermudaGrass73.addComponentOrReplace(gltfShape2)
const transform75 = new Transform({
  position: new Vector3(40, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass73.addComponentOrReplace(transform75)

const bermudaGrass74 = new Entity('bermudaGrass74')
engine.addEntity(bermudaGrass74)
bermudaGrass74.setParent(_scene)
bermudaGrass74.addComponentOrReplace(gltfShape2)
const transform76 = new Transform({
  position: new Vector3(56, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass74.addComponentOrReplace(transform76)

const bermudaGrass75 = new Entity('bermudaGrass75')
engine.addEntity(bermudaGrass75)
bermudaGrass75.setParent(_scene)
bermudaGrass75.addComponentOrReplace(gltfShape2)
const transform77 = new Transform({
  position: new Vector3(72, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass75.addComponentOrReplace(transform77)

const bermudaGrass76 = new Entity('bermudaGrass76')
engine.addEntity(bermudaGrass76)
bermudaGrass76.setParent(_scene)
bermudaGrass76.addComponentOrReplace(gltfShape2)
const transform78 = new Transform({
  position: new Vector3(88, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass76.addComponentOrReplace(transform78)

const bermudaGrass77 = new Entity('bermudaGrass77')
engine.addEntity(bermudaGrass77)
bermudaGrass77.setParent(_scene)
bermudaGrass77.addComponentOrReplace(gltfShape2)
const transform79 = new Transform({
  position: new Vector3(104, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass77.addComponentOrReplace(transform79)

const bermudaGrass78 = new Entity('bermudaGrass78')
engine.addEntity(bermudaGrass78)
bermudaGrass78.setParent(_scene)
bermudaGrass78.addComponentOrReplace(gltfShape2)
const transform80 = new Transform({
  position: new Vector3(120, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass78.addComponentOrReplace(transform80)

const bermudaGrass79 = new Entity('bermudaGrass79')
engine.addEntity(bermudaGrass79)
bermudaGrass79.setParent(_scene)
bermudaGrass79.addComponentOrReplace(gltfShape2)
const transform81 = new Transform({
  position: new Vector3(136, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass79.addComponentOrReplace(transform81)

const bermudaGrass80 = new Entity('bermudaGrass80')
engine.addEntity(bermudaGrass80)
bermudaGrass80.setParent(_scene)
bermudaGrass80.addComponentOrReplace(gltfShape2)
const transform82 = new Transform({
  position: new Vector3(152, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass80.addComponentOrReplace(transform82)

const bermudaGrass81 = new Entity('bermudaGrass81')
engine.addEntity(bermudaGrass81)
bermudaGrass81.setParent(_scene)
bermudaGrass81.addComponentOrReplace(gltfShape2)
const transform83 = new Transform({
  position: new Vector3(8, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass81.addComponentOrReplace(transform83)

const bermudaGrass82 = new Entity('bermudaGrass82')
engine.addEntity(bermudaGrass82)
bermudaGrass82.setParent(_scene)
bermudaGrass82.addComponentOrReplace(gltfShape2)
const transform84 = new Transform({
  position: new Vector3(24, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass82.addComponentOrReplace(transform84)

const bermudaGrass83 = new Entity('bermudaGrass83')
engine.addEntity(bermudaGrass83)
bermudaGrass83.setParent(_scene)
bermudaGrass83.addComponentOrReplace(gltfShape2)
const transform85 = new Transform({
  position: new Vector3(40, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass83.addComponentOrReplace(transform85)

const bermudaGrass84 = new Entity('bermudaGrass84')
engine.addEntity(bermudaGrass84)
bermudaGrass84.setParent(_scene)
bermudaGrass84.addComponentOrReplace(gltfShape2)
const transform86 = new Transform({
  position: new Vector3(56, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass84.addComponentOrReplace(transform86)

const bermudaGrass85 = new Entity('bermudaGrass85')
engine.addEntity(bermudaGrass85)
bermudaGrass85.setParent(_scene)
bermudaGrass85.addComponentOrReplace(gltfShape2)
const transform87 = new Transform({
  position: new Vector3(72, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass85.addComponentOrReplace(transform87)

const bermudaGrass86 = new Entity('bermudaGrass86')
engine.addEntity(bermudaGrass86)
bermudaGrass86.setParent(_scene)
bermudaGrass86.addComponentOrReplace(gltfShape2)
const transform88 = new Transform({
  position: new Vector3(88, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass86.addComponentOrReplace(transform88)

const bermudaGrass87 = new Entity('bermudaGrass87')
engine.addEntity(bermudaGrass87)
bermudaGrass87.setParent(_scene)
bermudaGrass87.addComponentOrReplace(gltfShape2)
const transform89 = new Transform({
  position: new Vector3(104, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass87.addComponentOrReplace(transform89)

const bermudaGrass88 = new Entity('bermudaGrass88')
engine.addEntity(bermudaGrass88)
bermudaGrass88.setParent(_scene)
bermudaGrass88.addComponentOrReplace(gltfShape2)
const transform90 = new Transform({
  position: new Vector3(120, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass88.addComponentOrReplace(transform90)

const bermudaGrass89 = new Entity('bermudaGrass89')
engine.addEntity(bermudaGrass89)
bermudaGrass89.setParent(_scene)
bermudaGrass89.addComponentOrReplace(gltfShape2)
const transform91 = new Transform({
  position: new Vector3(136, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass89.addComponentOrReplace(transform91)

const bermudaGrass90 = new Entity('bermudaGrass90')
engine.addEntity(bermudaGrass90)
bermudaGrass90.setParent(_scene)
bermudaGrass90.addComponentOrReplace(gltfShape2)
const transform92 = new Transform({
  position: new Vector3(152, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass90.addComponentOrReplace(transform92)

const bermudaGrass91 = new Entity('bermudaGrass91')
engine.addEntity(bermudaGrass91)
bermudaGrass91.setParent(_scene)
bermudaGrass91.addComponentOrReplace(gltfShape2)
const transform93 = new Transform({
  position: new Vector3(8, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass91.addComponentOrReplace(transform93)

const bermudaGrass92 = new Entity('bermudaGrass92')
engine.addEntity(bermudaGrass92)
bermudaGrass92.setParent(_scene)
bermudaGrass92.addComponentOrReplace(gltfShape2)
const transform94 = new Transform({
  position: new Vector3(24, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass92.addComponentOrReplace(transform94)

const bermudaGrass93 = new Entity('bermudaGrass93')
engine.addEntity(bermudaGrass93)
bermudaGrass93.setParent(_scene)
bermudaGrass93.addComponentOrReplace(gltfShape2)
const transform95 = new Transform({
  position: new Vector3(40, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass93.addComponentOrReplace(transform95)

const bermudaGrass94 = new Entity('bermudaGrass94')
engine.addEntity(bermudaGrass94)
bermudaGrass94.setParent(_scene)
bermudaGrass94.addComponentOrReplace(gltfShape2)
const transform96 = new Transform({
  position: new Vector3(56, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass94.addComponentOrReplace(transform96)

const bermudaGrass95 = new Entity('bermudaGrass95')
engine.addEntity(bermudaGrass95)
bermudaGrass95.setParent(_scene)
bermudaGrass95.addComponentOrReplace(gltfShape2)
const transform97 = new Transform({
  position: new Vector3(72, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass95.addComponentOrReplace(transform97)

const bermudaGrass96 = new Entity('bermudaGrass96')
engine.addEntity(bermudaGrass96)
bermudaGrass96.setParent(_scene)
bermudaGrass96.addComponentOrReplace(gltfShape2)
const transform98 = new Transform({
  position: new Vector3(88, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass96.addComponentOrReplace(transform98)

const bermudaGrass97 = new Entity('bermudaGrass97')
engine.addEntity(bermudaGrass97)
bermudaGrass97.setParent(_scene)
bermudaGrass97.addComponentOrReplace(gltfShape2)
const transform99 = new Transform({
  position: new Vector3(104, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass97.addComponentOrReplace(transform99)

const bermudaGrass98 = new Entity('bermudaGrass98')
engine.addEntity(bermudaGrass98)
bermudaGrass98.setParent(_scene)
bermudaGrass98.addComponentOrReplace(gltfShape2)
const transform100 = new Transform({
  position: new Vector3(120, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass98.addComponentOrReplace(transform100)

const bermudaGrass99 = new Entity('bermudaGrass99')
engine.addEntity(bermudaGrass99)
bermudaGrass99.setParent(_scene)
bermudaGrass99.addComponentOrReplace(gltfShape2)
const transform101 = new Transform({
  position: new Vector3(136, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass99.addComponentOrReplace(transform101)

const bermudaGrass100 = new Entity('bermudaGrass100')
engine.addEntity(bermudaGrass100)
bermudaGrass100.setParent(_scene)
bermudaGrass100.addComponentOrReplace(gltfShape2)
const transform102 = new Transform({
  position: new Vector3(152, 0, 152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bermudaGrass100.addComponentOrReplace(transform102)

const imageFromURL = new Entity('imageFromURL')
engine.addEntity(imageFromURL)
imageFromURL.setParent(_scene)
const transform103 = new Transform({
  position: new Vector3(80, 0, 80),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
imageFromURL.addComponentOrReplace(transform103)

const imageFromURL2 = new Entity('imageFromURL2')
engine.addEntity(imageFromURL2)
imageFromURL2.setParent(_scene)
const transform104 = new Transform({
  position: new Vector3(86.47428894042969, 3.3984320163726807, 71.58231353759766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.677594184875488, 3.9398539066314697, 1)
})
imageFromURL2.addComponentOrReplace(transform104)

const imageFromURL3 = new Entity('imageFromURL3')
engine.addEntity(imageFromURL3)
imageFromURL3.setParent(_scene)
const transform105 = new Transform({
  position: new Vector3(97.78472137451172, 2.9165682792663574, 83.9977798461914),
  rotation: new Quaternion(7.459749815646067e-16, 0.6920113563537598, -8.249416083572214e-8, -0.7218866944313049),
  scale: new Vector3(3.3376822471618652, 4.330127239227295, 0.9995726346969604)
})
imageFromURL3.addComponentOrReplace(transform105)

const imageFromURL4 = new Entity('imageFromURL4')
engine.addEntity(imageFromURL4)
imageFromURL4.setParent(_scene)
const transform106 = new Transform({
  position: new Vector3(86.20764923095703, 3.0081820487976074, 90.78960418701172),
  rotation: new Quaternion(-1.2573116511685814e-14, 0.9999154210090637, -1.191991927385061e-7, -0.01300913468003273),
  scale: new Vector3(4.256339073181152, 4.821140766143799, 0.9999927878379822)
})
imageFromURL4.addComponentOrReplace(transform106)

const imageFromURL5 = new Entity('imageFromURL5')
engine.addEntity(imageFromURL5)
imageFromURL5.setParent(_scene)
const transform107 = new Transform({
  position: new Vector3(88.14149475097656, 10.616735458374023, 93.36133575439453),
  rotation: new Quaternion(-1.2573116511685814e-14, 0.9999154210090637, -1.191991927385061e-7, -0.01300913468003273),
  scale: new Vector3(2.3666534423828125, 2.3057773113250732, 0.9996601939201355)
})
imageFromURL5.addComponentOrReplace(transform107)

const imageFromURL6 = new Entity('imageFromURL6')
engine.addEntity(imageFromURL6)
imageFromURL6.setParent(_scene)
const transform108 = new Transform({
  position: new Vector3(97.78472137451172, 10.078629493713379, 74.37186431884766),
  rotation: new Quaternion(7.459749815646067e-16, 0.6920113563537598, -8.249416083572214e-8, -0.7218866944313049),
  scale: new Vector3(3.3376879692077637, 3.3309645652770996, 0.9995745420455933)
})
imageFromURL6.addComponentOrReplace(transform108)

const imageFromURL7 = new Entity('imageFromURL7')
engine.addEntity(imageFromURL7)
imageFromURL7.setParent(_scene)
const transform109 = new Transform({
  position: new Vector3(97.78472137451172, 10.078629493713379, 80.38819885253906),
  rotation: new Quaternion(7.459749815646067e-16, 0.6920113563537598, -8.249416083572214e-8, -0.7218866944313049),
  scale: new Vector3(3.337688684463501, 3.3309645652770996, 0.9995747804641724)
})
imageFromURL7.addComponentOrReplace(transform109)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
script1.init(options)
script1.spawn(imageFromURL, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageFromURL, channelBus))
script1.spawn(imageFromURL2, {"image":"https://i.imgur.com/Lv54nwG.png"}, createChannel(channelId, imageFromURL2, channelBus))
script1.spawn(imageFromURL3, {"image":"https://i.imgur.com/oCVU5fD.jpg"}, createChannel(channelId, imageFromURL3, channelBus))
script1.spawn(imageFromURL4, {"image":"https://i.imgur.com/L32W9Tq.jpg"}, createChannel(channelId, imageFromURL4, channelBus))
script1.spawn(imageFromURL5, {"image":"https://i.imgur.com/S9NzkIW.png"}, createChannel(channelId, imageFromURL5, channelBus))
script1.spawn(imageFromURL6, {"image":"https://i.imgur.com/SzSesoi.png"}, createChannel(channelId, imageFromURL6, channelBus))
script1.spawn(imageFromURL7, {"image":"https://i.imgur.com/chdM8jK.png"}, createChannel(channelId, imageFromURL7, channelBus))